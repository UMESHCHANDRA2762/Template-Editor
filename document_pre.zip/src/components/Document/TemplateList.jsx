import React from "react";
import TemplateActions from "./TemplateActions";

const TemplateList = ({ templates, onEdit, onDelete, onView }) => {
  return (
    <div className="w-100">
      <div className="table-responsive">
        <div
          className="d-none d-md-flex bg-light px-3 py-2 rounded"
          style={{
            fontWeight: 600,
            color: "#333",
            border: "1px solid #dee2e6",
          }}
        >
          <div
            className="flex-shrink-0 flex-grow-1"
            style={{ minWidth: "200px", maxWidth: "25%" }}
          >
            Document Name
          </div>
          <div
            className="flex-shrink-0 flex-grow-1"
            style={{ minWidth: "150px", maxWidth: "20%" }}
          >
            Folder
          </div>
          <div
            className="flex-shrink-0 flex-grow-1"
            style={{ minWidth: "150px", maxWidth: "20%" }}
          >
            Action Type
          </div>
          <div
            className="flex-shrink-0 flex-grow-1"
            style={{ minWidth: "150px", maxWidth: "20%" }}
          >
            Last Used
          </div>
          <div
            className="flex-shrink-0 text-end"
            style={{ minWidth: "140px", maxWidth: "15%" }}
          >
            Actions
          </div>
        </div>

        {templates.length === 0 ? (
          <div className="text-center py-4 text-muted">
            No templates available.
          </div>
        ) : (
          templates.map((template) => (
            <React.Fragment key={template.id}>
              {/* Desktop row layout */}
              <div
                className="d-none d-md-flex align-items-center px-3 py-2 border-bottom"
                style={{ backgroundColor: "#fff", minWidth: "800px" }}
              >
                <div
                  className="flex-shrink-0 flex-grow-1 text-truncate"
                  style={{
                    minWidth: "200px",
                    maxWidth: "25%",
                    color: "#4B0082",
                    fontWeight: 600,
                  }}
                  title={template.documentName}
                >
                  {template.documentName}
                </div>

                <div
                  className="flex-shrink-0 flex-grow-1 d-flex align-items-center text-truncate"
                  style={{ minWidth: "150px", maxWidth: "20%", gap: "5px" }}
                  title="Employee letters"
                >
                  <i className="bi bi-folder2-open"></i>
                  <span>Employee letters</span>
                </div>

                <div
                  className="flex-shrink-0 flex-grow-1 d-flex align-items-center text-truncate"
                  style={{ minWidth: "150px", maxWidth: "20%", gap: "5px" }}
                  title="Document Generation"
                >
                  <i className="bi bi-file-earmark"></i>
                  <span>Document Generation</span>
                </div>

                <div
                  className="flex-shrink-0 flex-grow-1 text-truncate"
                  style={{ minWidth: "150px", maxWidth: "20%" }}
                  title={template.lastUsed}
                >
                  {template.lastUsed}
                </div>

                <div
                  className="flex-shrink-0 d-flex align-items-center justify-content-end flex-nowrap"
                  style={{ minWidth: "140px", maxWidth: "15%", gap: "8px" }}
                >
                  <TemplateActions
                    template={template}
                    onView={onView}
                    onEdit={onEdit}
                    onDelete={onDelete}
                  />
                </div>
              </div>

              {/* Mobile card layout */}
              <div className="d-flex d-md-none flex-column border rounded p-3 my-2 bg-white shadow-sm">
                <div className="mb-2">
                  <strong>Document Name:</strong>{" "}
                  <span className="text-primary">{template.documentName}</span>
                </div>
                <div className="mb-2">
                  <strong>Folder:</strong>{" "}
                  <span>
                    <i className="bi bi-folder2-open me-1" />
                    Employee letters
                  </span>
                </div>
                <div className="mb-2">
                  <strong>Action Type:</strong>{" "}
                  <span>
                    <i className="bi bi-file-earmark me-1" />
                    Document Generation
                  </span>
                </div>
                <div className="mb-2">
                  <strong>Last Used:</strong> <span>{template.lastUsed}</span>
                </div>
                <div className="d-flex justify-content-end gap-2 mt-2">
                  <TemplateActions
                    template={template}
                    onView={onView}
                    onEdit={onEdit}
                    onDelete={onDelete}
                  />
                </div>
              </div>
            </React.Fragment>
          ))
        )}
      </div>
    </div>
  );
};

export default TemplateList;
