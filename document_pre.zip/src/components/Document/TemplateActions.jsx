import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const TemplateActions = ({ template, onEdit, onDelete, onView }) => {
  const [showOptions, setShowOptions] = useState(false);
  const navigate = useNavigate();

  const handleAction = (action) => {
    switch (action) {
      case "view":
        onView(template);
        break;
      case "edit":
        onEdit(template);
        break;
      case "delete":
        if (
          window.confirm(
            `Are you sure you want to delete "${template.documentName}"?`
          )
        ) {
          onDelete(template.id);
        }
        break;
      default:
        break;
    }
    setShowOptions(false);
  };

  return (
    <div
      className="d-flex align-items-center justify-content-end gap-2 flex-nowrap"
      style={{ minWidth: "140px" }}
    >
      {/* Generate Button */}
      <button
        className="btn btn-sm btn-outline-primary"
        onClick={() =>
          navigate("/finalize", { state: { content: template.content } })
        }
      >
        Generate
      </button>

      {/* Three Dots Button */}
      <div className="position-relative">
        <button
          className="btn btn-sm p-1"
          style={{
            background: "transparent",
            border: "none",
            fontSize: "20px",
            lineHeight: "1",
          }}
          onClick={() => setShowOptions((prev) => !prev)}
        >
          &#x22EE;
        </button>

        {showOptions && (
          <div
            className="dropdown-menu show"
            style={{
              position: "absolute",
              top: "100%",
              right: 0,
              minWidth: "120px",
              boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
              zIndex: 1050,
            }}
          >
            <button
              className="dropdown-item"
              onClick={() => handleAction("view")}
            >
              View
            </button>
            <button
              className="dropdown-item"
              onClick={() => handleAction("edit")}
            >
              Edit
            </button>
            <button
              className="dropdown-item"
              onClick={() => handleAction("delete")}
            >
              Delete
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TemplateActions;
