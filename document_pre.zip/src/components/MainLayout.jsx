// src/components/MainLayout.jsx

import React, { useEffect, useRef } from "react";
import { useLocation, Outlet } from "react-router-dom";
import Sidebar from "./layout/Sidebar";
import Header from "./layout/Header";
import TopNav from "./layout/TopNav";
import "bootstrap/dist/css/bootstrap.min.css";

function MainLayout() {
  const location = useLocation();
  const searchRef = useRef(null);

  // Define routes that should render without sidebar/header/topnav
  const isPlainPage = ["/setup", "/compose", "/finalize"].includes(
    location.pathname
  );

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.altKey && e.key.toLowerCase() === "k") {
        e.preventDefault();
        if (searchRef.current) {
          searchRef.current.focus();
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  if (isPlainPage) {
    // Render just the page content (SetUp, Compose, Finalize) without sidebar/header
    return <Outlet />;
  }

  // For all other routes, render full layout with sidebar, header, topnav
  return (
    <div className="container-fluid p-0">
      <div
        className="row g-0 flex-wrap"
        style={{ height: "100vh", overflow: "hidden" }}
      >
        <Sidebar />

        <div className="col d-flex flex-column" style={{ minWidth: 0 }}>
          <Header searchRef={searchRef} />

          <TopNav />

          <div className="p-4 flex-grow-1 overflow-auto">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainLayout;
