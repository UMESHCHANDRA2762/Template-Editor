import React from "react";
import "bootstrap-icons/font/bootstrap-icons.css";

function Header({ searchRef, toggleSidebar }) {
  return (
    <header
      className="text-white"
      style={{
        backgroundColor: "#4B0082",
        paddingTop: "15px",
        paddingBottom: "15px",
      }}
    >
      <div className="container-fluid">
        <div className="row align-items-center gy-3 gy-md-0">
          <div className="col-md-4 col-lg-3 d-flex align-items-center">
            {typeof toggleSidebar === "function" && (
              <button
                className="btn btn-link d-md-none p-0 me-2"
                type="button"
                onClick={toggleSidebar}
                aria-label="Toggle sidebar"
                style={{ color: "white", lineHeight: 1 }}
              >
                <i className="bi bi-list" style={{ fontSize: "1.8rem" }}></i>
              </button>
            )}
            <h1
              className="m-0 text-center text-md-start"
              style={{
                fontSize: "1rem",
                fontWeight: "bold",
                whiteSpace: "nowrap",
              }}
            >
              SYSTECHCORP PVT. LTD.
            </h1>
          </div>

          <div className="col-md-5 col-lg-6 order-md-1 order-2">
            <div
              className="position-relative mx-auto"
              style={{
                maxWidth: "600px",
              }}
            >
              <i
                className="bi bi-search position-absolute"
                style={{
                  left: "16px",
                  top: "50%",
                  transform: "translateY(-50%)",
                  color: "#888",
                  fontSize: "1rem",
                  zIndex: 1,
                }}
              ></i>
              <input
                ref={searchRef}
                type="text"
                className="form-control rounded-pill ps-5 pe-5"
                placeholder="Search employees or actions (Ex: Apply Leave)"
                style={{
                  width: "100%",
                  paddingRight: "70px",
                }}
              />
              <button
                className="position-absolute d-none d-md-block"
                style={{
                  right: "10px",
                  top: "50%",
                  transform: "translateY(-50%)",
                  backgroundColor: "#f1f1f1",
                  border: "1px solid #ccc",
                  borderRadius: "6px",
                  padding: "3px 8px",
                  fontSize: "0.75rem",
                  lineHeight: 1.2,
                  color: "#333",
                  cursor: "pointer",
                  zIndex: 2,
                }}
                title="Shortcut: Alt+K"
                onClick={() => searchRef.current && searchRef.current.focus()}
              >
                Alt+K
              </button>
            </div>
          </div>

          <div className="col-md-3 col-lg-3 order-md-2 order-1">
            <div
              className="d-flex align-items-center justify-content-center justify-content-md-end"
              style={{ fontSize: "1.3rem", gap: "1rem" }}
            >
              <i
                className="bi bi-rocket-takeoff"
                style={{ cursor: "pointer" }}
                title="Quick Launch"
              ></i>
              <i
                className="bi bi-gear"
                style={{ cursor: "pointer" }}
                title="Settings"
              ></i>
              <i
                className="bi bi-question-circle"
                style={{ cursor: "pointer" }}
                title="Help"
              ></i>
              <div
                style={{
                  width: "35px",
                  height: "35px",
                  borderRadius: "50%",
                  backgroundColor: "#FFAA33",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontWeight: "bold",
                  color: "#4B0082",
                  fontSize: "0.9rem",
                  cursor: "pointer",
                  border: "1px solid #fff",
                }}
                title="Umesh Chandra"
              >
                UC
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
