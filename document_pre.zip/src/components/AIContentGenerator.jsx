// components/AIContentGenerator.jsx
import React, { useState } from "react";
import { GoogleGenerativeAI } from "@google/generative-ai";

const AIContentGenerator = ({ quillRef }) => {
  const [showModal, setShowModal] = useState(false);
  const [promptText, setPromptText] = useState(
    "Write a professional opening paragraph for an employee offer letter."
  );
  const [loading, setLoading] = useState(false);

  const transformMarkdownStarsToHTML = (text) => {
    let result = text.replace(/\*\*\s*(.*?)\s*\*\*/g, "<strong>$1</strong> ");
    const lines = result.split("\n");
    const listItems = [];
    const normalLines = [];

    lines.forEach((line) => {
      if (line.startsWith("* ")) {
        listItems.push(line.slice(2));
      } else {
        normalLines.push(line);
      }
    });

    if (listItems.length > 0) {
      const ul = `<ul>${listItems
        .map((item) => `<li>${item}</li>`)
        .join("")}</ul>`;
      result = normalLines.join("\n") + "\n" + ul;
    }

    return result;
  };

  const handleAISuggestion = async () => {
    setLoading(true);
    try {
      const genAI = new GoogleGenerativeAI(
        "AIzaSyDz3wcv9v4LhzHtav6Hs4GxeLCA8AFpCvQ"
      );

      const model = genAI.getGenerativeModel({
        model: "gemini-2.0-flash",
        safetySettings: [
          { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
          { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
          {
            category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
            threshold: "BLOCK_NONE",
          },
          {
            category: "HARM_CATEGORY_DANGEROUS_CONTENT",
            threshold: "BLOCK_NONE",
          },
        ],
      });

      const result = await model.generateContent(promptText);
      const response = await result.response;
      let aiText = await response.text();
      aiText = transformMarkdownStarsToHTML(aiText);

      const styledText = `<p style="font-style: poppins; background: #f4f4f4; padding: 10px; border-left: 4px solid #007bff; margin-top: 10px;">${aiText}</p>`;

      const editor = quillRef.current?.getEditor();
      if (editor) {
        const selection = editor.getSelection();
        const index = selection ? selection.index : editor.getLength();
        editor.clipboard.dangerouslyPasteHTML(index, styledText);
      }

      setShowModal(false);
    } catch (error) {
      console.error("Gemini AI error:", error);
      alert("AI generation failed. Please check your setup.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button
        className="btn btn-primary mx-auto d-block"
        onClick={() => setShowModal(true)}
        title="Generate Content with AI"
        style={{ minWidth: "180px" }}
      >
        Generate using AI
      </button>

      {showModal && (
        <div
          className="modal fade show d-block"
          tabIndex="-1"
          style={{ background: "rgba(0,0,0,0.5)" }}
        >
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Generate Content with AI</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowModal(false)}
                ></button>
              </div>
              <div className="modal-body">
                <textarea
                  rows={4}
                  className="form-control"
                  placeholder="Enter your prompt..."
                  value={promptText}
                  onChange={(e) => setPromptText(e.target.value)}
                ></textarea>
              </div>
              <div className="modal-footer">
                <button
                  className="btn btn-secondary"
                  onClick={() => setShowModal(false)}
                >
                  Cancel
                </button>
                <button
                  className="btn btn-primary"
                  onClick={handleAISuggestion}
                  disabled={loading}
                >
                  {loading ? "Generating..." : "Generate"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AIContentGenerator;
