import React from "react";

const RightSidebar = () => {
  return (
    <div
      className="d-flex flex-column p-4 bg-light"
      style={{
        width: "250px",
        height: "100vh", 
        overflow: "hidden",
        flexShrink: 0, 
      }}
    >
  
    </div>
  );
};

export default RightSidebar;
